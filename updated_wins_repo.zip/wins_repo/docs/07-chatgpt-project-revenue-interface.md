# ChatGPT Project Revenue Interface: Show Time Savings

This guide explains how to add new elements to the **“ChatGPT Project Revenue”** interface in Airtable to display the **Overall Time it would Save (hours per year)** for each win and to calculate total time saved.

## Add a Field Display

1. Open your base in Airtable and click **Interfaces**.
2. Select **ChatGPT Project Revenue** and click **Edit**.
3. If the interface uses a **record detail panel** or **card view**, add a **Field** element (or **Number** field display) and bind it to **Overall Time it would Save (hours per year)**.  Position it near other key metrics like Value and Priority.

## Add Total Hours Saved Overall

1. In the edit view, add a **Metric** or **KPI** card.
2. Set the label to **Total Hours Saved Overall**.
3. Choose **Overall Time it would Save (hours per year)** as the field to aggregate, and select **Sum** as the aggregation.
4. Ensure the data source covers all records (no filters), so it sums across every win in the table.
5. Save the layout.

## Add Total Hours Saved This Month

1. Create a new **Metric** card.
2. Set the label to **Total Hours Saved This Month**.
3. Choose **Overall Time it would Save (hours per year)** as the field to aggregate with **Sum**.
4. Add a filter: **Date is in this month** (or similar “current month” filter) to restrict the records.
5. If you want a true per‑month figure rather than annual hours, create a formula field in your table named `Hours Saved per month` with a formula like `{Overall Time it would Save (hours per year)} / 12`, then use that field for this metric.
6. Save the layout and publish the interface.

## Redaction Note

When sharing screenshots of this interface, be careful to remove or blur any fields that could reveal private project names, descriptions or links.  Aggregate numbers and generic field labels are safe to share.