# Optional Scripts and Configuration

This folder contains **optional** resources for advanced users who wish to interact with
Airtable directly via its REST API instead of using the ChatGPT Airtable connector.
These scripts and configuration files are **not required** for the core wins tracker
workflow described in the rest of this repository.  The connector handles all
authentication and API calls on your behalf, so you do not need API tokens or base IDs
to use the Wins Tracker.

## Contents

- **scripts/python/** – A minimal example script (`upsert_win.py`) and its
  dependencies (`requirements.txt`) for creating records in Airtable via the REST
  API.  Use this only if you have a specific need to perform batch operations or
  automate tasks outside of ChatGPT.
- **.env.example** – A template for environment variables used by the scripts.
  It defines placeholders for an Airtable Personal Access Token, base ID and table
  name, as well as default hourly rates and a preferred time zone.  **Do not**
  fill in real values or commit a `.env` file containing secrets to version control.

## When to Use

Most users should **ignore** this folder and stick to the built‑in Airtable connector.
The connector provides a secure, no‑code way to read and write data without
managing keys or IDs.  Only explore these scripts if you are comfortable with
programming, have a specific automation task in mind, and understand how to
protect your secrets (e.g. via environment variables).

## Secret Handling

If you do decide to use the scripts:

- Copy `.env.example` to `.env` and set the variables accordingly.
- Never commit `.env` or any file containing real API tokens or IDs.
- Follow the [redaction and security guidelines](../docs/05-redaction-and-security.md)
  before sharing or publishing your work.
