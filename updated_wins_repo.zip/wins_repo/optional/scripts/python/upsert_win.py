"""
Optional script for advanced users who wish to interact with Airtable via the REST API.

This script is *not* required when using the ChatGPT Airtable connector.  It demonstrates how to
create a new record in your Airtable base using environment variables for configuration.  Do not
commit your `.env` file or API tokens to version control.

Usage:
    1. Install dependencies: `pip install -r requirements.txt`
    2. Create a `.env` file based on `.env.example` and fill in your AIRTABLE_TOKEN, AIRTABLE_BASE_ID
       and AIRTABLE_TABLE_NAME.  Do not commit this file.
    3. Run the script: `python upsert_win.py --title "My Win" --status "Complete" --value 150`

The script will construct a record payload and POST it to the Airtable API.  See the README
for safer ways to use the connector instead of manual API calls.
"""

import argparse
import os
import requests
from dotenv import load_dotenv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a record in Airtable")
    parser.add_argument("--title", required=True, help="Title of the win")
    parser.add_argument("--status", required=True, help="Status (e.g. Complete, In progress)")
    parser.add_argument("--date", default="", help="Date of the win (YYYY-MM-DD)")
    parser.add_argument("--what_i_did", default="", help="Description of what you did")
    parser.add_argument("--impact", default="", help="Impact of the win")
    parser.add_argument("--links", default="", help="Relevant links")
    parser.add_argument("--value", type=float, default=0.0, help="Monetary value estimate (USD)")
    parser.add_argument("--tags", default="", help="Comma-separated tags (automation, home-ops, printing, productivity, tracking)")
    parser.add_argument("--notes", default="", help="Additional notes")
    parser.add_argument("--priority", default="P5", help="Priority (P1–P10)")
    parser.add_argument("--next_steps", default="", help="Next steps or follow-up actions")
    return parser.parse_args()


def build_payload(args: argparse.Namespace) -> dict:
    """Construct the Airtable payload."""
    fields = {
        "Title": args.title,
        "Status": args.status,
        "Date": args.date,
        "What I did": args.what_i_did,
        "Impact": args.impact,
        "Links": args.links,
        "URL": f"${int(args.value)}" if args.value else "",
        "Multiple Select": [tag.strip() for tag in args.tags.split(",") if tag.strip()],
        "Notes": args.notes,
        "Priority": args.priority,
        "Cost Value Justification": "",
        "Next Steps": args.next_steps,
    }
    return {"fields": fields}


def main() -> None:
    load_dotenv()
    token = os.getenv("AIRTABLE_TOKEN")
    base_id = os.getenv("AIRTABLE_BASE_ID")
    table_name = os.getenv("AIRTABLE_TABLE_NAME")
    if not all([token, base_id, table_name]):
        raise SystemExit(
            "Missing configuration.  Ensure AIRTABLE_TOKEN, AIRTABLE_BASE_ID and AIRTABLE_TABLE_NAME are set in your .env file."
        )
    args = parse_args()
    payload = build_payload(args)

    url = f"https://api.airtable.com/v0/{base_id}/{table_name.replace(' ', '%20')}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    response = requests.post(url, json=payload, headers=headers)
    if response.ok:
        print("Record created successfully:", response.json())
    else:
        print("Error creating record:", response.status_code, response.text)


if __name__ == "__main__":
    main()